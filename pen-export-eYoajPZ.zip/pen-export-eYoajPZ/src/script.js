function startTimer() {
    var hoursSpan = document.querySelector('.time-block:nth-child(1) .time');
    var minutesSpan = document.querySelector('.time-block:nth-child(3) .time');
    var secondsSpan = document.querySelector('.time-block:nth-child(5) .time');

    var hours = parseInt(hoursSpan.textContent, 10);
    var minutes = parseInt(minutesSpan.textContent, 10);
    var seconds = parseInt(secondsSpan.textContent, 10);

    var totalSeconds = hours * 3600 + minutes * 60 + seconds;

    setInterval(function () {
        totalSeconds--;
        if (totalSeconds < 0) {
            totalSeconds = 10 * 3600 + 59 * 60 + 30; // перезапустить таймер с начальными значениями
        }

        hours = parseInt(totalSeconds / 3600, 10);
        minutes = parseInt((totalSeconds % 3600) / 60, 10);
        seconds = parseInt(totalSeconds % 60, 10);

        hoursSpan.textContent = hours < 10 ? "0" + hours : hours;
        minutesSpan.textContent = minutes < 10 ? "0" + minutes : minutes;
        secondsSpan.textContent = seconds < 10 ? "0" + seconds : seconds;
    }, 1000);
}

document.addEventListener('DOMContentLoaded', startTimer);
